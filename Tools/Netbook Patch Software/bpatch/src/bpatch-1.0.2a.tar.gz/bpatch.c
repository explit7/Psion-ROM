#include <stdio.h>

#define PRGAUTHOR "Poke aka Petr Petyovsky 2004-2005"
#define PRGNAME   "bpatch"
#define PRGVER    "1.02"

struct TPatchRow /* one row of patch file */
	{
	unsigned long ofs;  /* position */
	unsigned char oldb; /* old byte */
	unsigned char newb; /* new byte */
	};

int linecnt = 0; /* patch file line counter */
int listing = 0; /* if set listing of patch_file is enabled */
int verbose = 0; /* if set verbose mode enabled */
int unpatch = 0; /* if set reverse patch mode (unpatch) */
int comment = 0; /* if set display comments from patch file */

int GetPatchRow(char *FileName, FILE *fpatch, struct TPatchRow *patch)
	{
	unsigned long ofs = 0;
	int oldb = -1, newb = -1;
	char str[257];
	while(fgets(str, 256, fpatch) != NULL)
		{
		linecnt++;
		if(listing)
			printf("> %s", str);
		switch(str[0])
			{
			case('!'): /* exclamation mark define minimal version of bpatch */
				if((unsigned char)str[1]>PRGVER[0]) /*'1' is same like a main version number */
					{
					fprintf(stderr, PRGNAME":error: For apply this patch file upgrade program "PRGNAME" to ver.%c.XX\n", str[1]);
					return(-2); /* This is obsolete version of bpatch need upgrade */
					}
			break;

			case('#'): /* Remark characters */
			case(';'):
			case('/'):
				if(comment)
					printf("%s", str);
			break;

			case('?'): /* Special characters, not used yet. */
			case('$'):
			case('<'):
			case('>'):
			break;

			case('\n'): /* Blank line ignored */
			case('\r'):
			break;

			default:   /* other line must be patch row */	
				if(sscanf(str, "%lx: %x %x",&ofs, &oldb, &newb) == 3)
					{
					if((oldb >= 0) && (oldb <= 255) && (newb >= 0) && (newb <= 255))
						{
						patch->ofs = ofs; 
						if(unpatch)
							{
							patch->oldb = (unsigned char)newb; 
							patch->newb = (unsigned char)oldb;
							}
						else
							{
							patch->oldb = (unsigned char)oldb; 
							patch->newb = (unsigned char)newb;
							}
						return(0); /* Ok. new patch row fetched */
						}
					else
						{
						fprintf(stderr, PRGNAME":%s:%d: error: wrong patch values.\n", FileName, linecnt);
						return(-3); /* some value isn't correct */
						}
					}
				else
					fprintf(stderr, PRGNAME":%s:%d: warning: only some garbage.\n", FileName, linecnt);
			} /* switch */
		} /* while */
	if(!feof(fpatch)) 
		{
		fprintf(stderr, PRGNAME":%s:%d: error: Cannot read next line.\n", FileName, linecnt);
		return(-4); /* fgets return NULL but EOF not reached, patch file integrity error */
		}
	return(-1); /* end of patch file */
	}

int PatchByte(char *FileName, FILE *file, struct TPatchRow *patch)
	{
	int oldb;
	if(fseek(file, patch->ofs, SEEK_SET))
		{
		fprintf(stderr, PRGNAME":%s:%#010lx: error: File seek failed.\n", FileName, patch->ofs);
		return(-1); /* File Seek failed */
		}
	if((unsigned long)ftell(file) != patch->ofs)
		{
		fprintf(stderr, PRGNAME":%s:%#010lx: error: File seek failed.\n", FileName, patch->ofs);
		return(-1); /* File Seek failed */
		}
	oldb = getc(file);
	if(oldb == patch->newb)
		{
		fprintf(stderr, PRGNAME":%s:%#010lx: warning: This position is already patched.\n", FileName, patch->ofs);
		return(1); /* already patched */
		}
	if(oldb != patch->oldb)
		{
		fprintf(stderr, PRGNAME":%s:%#010lx: error: Old byte in file is different.\n", FileName, patch->ofs);
		return(-2); /* byte in file isn't same like a byteold */
		}
	if(fseek(file, -1, SEEK_CUR))
		{
		fprintf(stderr, PRGNAME":%s:%#010lx: error: File seek failed.\n", FileName, patch->ofs);
		return(-3); /* File Seek failed */
		}
	if((unsigned long)ftell(file) != patch->ofs)
		{
		fprintf(stderr, PRGNAME":%s:%#010lx: error: File seek failed.\n", FileName, patch->ofs);
		return(-3); /* File Seek failed */
		}
	if(putc(patch->newb, file) != patch->newb)
		{
		fprintf(stderr, PRGNAME":%s:%#010lx: error: Cannot write byte to the file.\n", FileName, patch->ofs);
		return(-4); /* Cannot write new byte */
		}
	return(0);
	}

void DisplayInfo(void)
	{
	printf(
		"GNU Binary patch ver."PRGVER" by: "PRGAUTHOR"\n\n"
		"Usage: "PRGNAME" [-u][-c][-l][-v][-h][-L] patch_file patched_file\n"
		"Options:\n"
		"  -u\tUnpatch (apply patch file in reverse order)\n"
		"  -c\tDisplay only comments from patch file\n"
		"  -l\tDisplay whole patch file\n"
		"  -v\tMore output (be verbose)\n" 
		"  -h\tThis help text, then exit\n"
		"  -L\tDisplay software license, then exit\n"
		"\n"
		"Report bugs to <pety@cis.vutbr.cz>.\n"
		);
	}
void DisplayLicense(void)
	{
	printf(
PRGNAME" ver."PRGVER", build ("__DATE__","__TIME__").\n"
"   Author: "PRGAUTHOR".\n"
"   This program is free software; you can redistribute it and/or modify\n"
"   it under the terms of the GNU General Public License as published by\n"
"   the Free Software Foundation; either version 2, or (at your option)\n"
"   any later version.\n"
"\n"
"   This program is distributed in the hope that it will be useful,\n"
"   but WITHOUT ANY WARRANTY; without even the implied warranty of\n"
"   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the\n"
"   GNU General Public License for more details.\n"
"\n"
"   You should have received a copy of the GNU General Public License\n"
"   along with this program; if not, write to the Free Software\n"
"   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.\n"
	);
	}

int main(int argn, char *argv[])
	{
	FILE *fpatch, *fdst;
	struct TPatchRow PatchRow;
	int arg;
	int stat_g, stat_p=0, stat_f=0;

	if(argn < 2) 
		{
		DisplayInfo();
		return(1);
		}
	for(arg=1; arg < argn; arg++)
		{
		if(argv[arg][0] != '-') 
			break;
		switch(argv[arg][1])
			{
			case('u'):
				unpatch = 1;
			break;
			case('c'):
				comment = 1;
			break;
			case('l'):
				listing = 1;
			break;
			case('v'):
				verbose = 1;
			break;
			case('h'):
				DisplayInfo();
				return(0);
			case('L'):
				DisplayLicense();
				return(0);
			default:
				printf("Unknown option switch: %s\n",argv[arg]);
				return(2);
			}
		}
	if(arg > (argn-2))
		{
		DisplayInfo();
		return(1);
		}
	if((fpatch=fopen(argv[arg],"rt")) == NULL)
		{
		fprintf(stderr, PRGNAME": error: Cannot open patch file: %s !\n",argv[arg]);
		return(3); /* File not found */
		}

	if((fdst=fopen(argv[arg+1],"rb+")) == NULL)
		{
		fprintf(stderr, PRGNAME": error: Cannot open file: %s !\n",argv[arg+1]);
		fclose(fpatch);
		return(4); /* File not found */
		}
	if(verbose) 
		printf("%s:\n",argv[arg+1]);
	do
		{
		stat_g = GetPatchRow(argv[arg], fpatch, &PatchRow);
		if(!stat_g)
			{
			stat_p = PatchByte(argv[arg+1],fdst,&PatchRow);
			if((!stat_p) && (verbose))
				printf("%08lx: %02x %02x .... ok.\n", PatchRow.ofs, PatchRow.oldb, PatchRow.newb);
			}
		}
	while( (stat_g >= 0) && (stat_p>=0));

	if(fclose(fdst))
		{
		fprintf(stderr, PRGNAME":warning: Cannot close output file: %s !\n",argv[arg+1]);
		stat_f = -1;
		}
	if(fclose(fpatch))
		{
		fprintf(stderr, PRGNAME":warning: Cannot close patch file: %s !\n",argv[arg]);
		}
	if((stat_g < -1) || (stat_p < 0) || (stat_f < 0))
		{
		fprintf(stderr, PRGNAME":error: %satching process failed.\n",(unpatch)?("Reverse p"):("P"));
		return(5); /* Patching process failed */
		}
	printf(PRGNAME":%satching process successfully done.\n",(unpatch)?("Reverse p"):("P"));
	return(0);	
	}
